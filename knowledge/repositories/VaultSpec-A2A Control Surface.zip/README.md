
  # VaultSpec-A2A Control Surface

  This is a code bundle for VaultSpec-A2A Control Surface. The original project is available at https://www.figma.com/design/EAs7Eh1lxKVzBqzke5HASU/VaultSpec-A2A-Control-Surface.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  