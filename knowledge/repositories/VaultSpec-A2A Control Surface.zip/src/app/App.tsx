import '../styles/index.css';
import { AppShell } from './components/layout/app-shell';

export default function App() {
  return <AppShell />;
}
