import { useEffect, useCallback, useState, useRef } from 'react';
import { Sidebar } from './sidebar';
import { StatusBar } from './status-bar';
import { TabBar } from './tab-bar';
import { MessageStream } from '../stream/message-stream';
import { InputBar } from '../stream/input-bar';
import { InspectorPanel } from '../inspector/inspector-panel';
import { PermissionModal } from '../permission/permission-modal';
import { useAppState } from '../../hooks/use-app-state';
import { demoPermissionRequest } from '../../data/mock-data';
import type { TeamPreset } from '../../data/types';

export function AppShell() {
  const state = useAppState();
  const {
    activeThread,
    activeEvents,
    activeTabId,
    inspectorTarget,
    openInspector,
    closeInspector,
    toggleContextPanel,
    contextDocuments,
    currentPermission,
    permissionQueue,
    respondToPermission,
    setPermissionQueue,
    createThread,
    teamPresets,
    toggleSidebar,
    openDocument,
    clearActiveTab,
    threads,
  } = state;

  const [selectedPreset, setSelectedPreset] = useState<TeamPreset | null>(teamPresets[0]);
  const [inspectorWidth, setInspectorWidth] = useState(420);
  const isResizingInspector = useRef(false);

  const isDark = state.themeMode === 'dark' || (state.themeMode === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches);

  // Keyboard shortcuts
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.ctrlKey && e.key === '.') {
        e.preventDefault();
        toggleSidebar();
      }
      if (e.ctrlKey && e.key === 'i') {
        e.preventDefault();
        if (inspectorTarget) closeInspector();
      }
      if (e.key === 'Escape') {
        if (inspectorTarget) closeInspector();
      }
      if (e.ctrlKey && e.key === 'n') {
        e.preventDefault();
        clearActiveTab();
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [toggleSidebar, inspectorTarget, closeInspector, clearActiveTab]);

  // Demo: trigger permission modal after 10s
  useEffect(() => {
    const timer = setTimeout(() => {
      setPermissionQueue([demoPermissionRequest]);
    }, 10000);
    return () => clearTimeout(timer);
  }, [setPermissionQueue]);

  const handleSend = useCallback(
    (message: string, opts?: {
      preset?: TeamPreset;
      repo?: string;
      branch?: string;
      featureTag?: string;
    }) => {
      if (!activeThread) {
        // Create mode — create a new thread
        createThread(message, {
          preset: opts?.preset || selectedPreset || undefined,
          repo: opts?.repo,
          branch: opts?.branch,
          featureTag: opts?.featureTag,
        });
      }
      // In message mode, sending to existing thread would go here
    },
    [activeThread, createThread, selectedPreset]
  );

  const isEmptyThread = activeThread && activeEvents.length === 0;
  const isNewThread = isEmptyThread || !activeThread;
  const activeTeam = activeThread ? teamPresets.find(p => p.id === activeThread.team_preset) : null;

  const handleToggleContext = useCallback(() => {
    toggleContextPanel(contextDocuments);
  }, [toggleContextPanel, contextDocuments]);

  const isContextOpen = inspectorTarget?.type === 'context_list';

  // Whether there's an active tab showing a thread with events
  const hasActiveTab = activeTabId !== null && activeThread !== null;

  // Inspector resize handler
  const handleInspectorMouseDown = useCallback(
    (e: React.MouseEvent) => {
      e.preventDefault();
      isResizingInspector.current = true;
      const startX = e.clientX;
      const startWidth = inspectorWidth;

      const onMouseMove = (ev: MouseEvent) => {
        if (!isResizingInspector.current) return;
        const newWidth = Math.max(260, Math.min(700, startWidth - (ev.clientX - startX)));
        setInspectorWidth(newWidth);
      };

      const onMouseUp = () => {
        isResizingInspector.current = false;
        document.removeEventListener('mousemove', onMouseMove);
        document.removeEventListener('mouseup', onMouseUp);
        document.body.style.cursor = '';
        document.body.style.userSelect = '';
      };

      document.body.style.cursor = 'col-resize';
      document.body.style.userSelect = 'none';
      document.addEventListener('mousemove', onMouseMove);
      document.addEventListener('mouseup', onMouseUp);
    },
    [inspectorWidth]
  );

  return (
    <div className="h-screen w-screen flex flex-col bg-background text-foreground overflow-hidden">
      <div className="flex-1 flex min-h-0">
        {/* Sidebar */}
        <Sidebar state={state} />

        {/* Main Content Area */}
        <div className="flex-1 flex flex-col min-h-0 min-w-0">
          {/* Tab Bar */}
          <TabBar state={state} />

          {/* Stream + Inspector row */}
          <div className="flex-1 flex min-h-0 min-w-0">
            {/* Stream Panel */}
            <div className="flex-1 flex flex-col min-h-0 min-w-0">
              {hasActiveTab ? (
                <>
                  <MessageStream
                    events={activeEvents}
                    onInspect={openInspector}
                    emptyState={isEmptyThread || false}
                    teamPreset={activeTeam || undefined}
                    agents={state.agents}
                    agentState={activeThread.agent_state}
                    onOpenDocument={openDocument}
                    onToggleContext={handleToggleContext}
                    isContextOpen={isContextOpen}
                    contextDocumentCount={contextDocuments.length}
                    isDark={isDark}
                  />
                  <InputBar
                    agentState={activeThread.agent_state}
                    onSend={handleSend}
                    onStop={() => {}}
                    teamPresets={teamPresets}
                    selectedPreset={activeTeam || selectedPreset}
                    onSelectPreset={setSelectedPreset}
                    isNewThread={!!isNewThread}
                    threads={threads}
                    activeThread={activeThread}
                    isDark={isDark}
                  />
                </>
              ) : (
                <>
                  {/* Empty state — no active tab */}
                  <div className="flex-1 flex items-center justify-center">
                    <div className="text-center select-none">
                      <h2 className="text-[1rem] font-semibold text-foreground/60 mb-1">VaultSpec</h2>
                      <p className="text-[0.75rem] text-muted-foreground">
                        Select a task from the sidebar, or create a new one below.
                      </p>
                    </div>
                  </div>
 
                  {/* Input bar in create mode */}
                  <InputBar
                    agentState="idle"
                    onSend={handleSend}
                    teamPresets={teamPresets}
                    selectedPreset={selectedPreset}
                    onSelectPreset={setSelectedPreset}
                    isNewThread={true}
                    threads={threads}
                    isDark={isDark}
                  />
                </>
              )}
            </div>

            {/* Inspector Panel */}
            {inspectorTarget && (
              <div className="relative shrink-0 h-full" style={{ width: `${inspectorWidth / 16}rem` }}>
                {/* Resize handle — left edge */}
                <div
                  onMouseDown={handleInspectorMouseDown}
                  className="absolute top-0 left-0 w-1 h-full cursor-col-resize hover:bg-primary/30 active:bg-primary/50 transition-colors z-30"
                />
                <InspectorPanel
                  target={inspectorTarget}
                  onClose={closeInspector}
                  isDark={isDark}
                  onOpenDocument={openDocument}
                />
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Status Bar */}
      <StatusBar state={state} />

      {/* Permission Modal */}
      {currentPermission && (
        <PermissionModal
          request={currentPermission}
          queueLength={permissionQueue.length}
          onRespond={respondToPermission}
        />
      )}
    </div>
  );
}
