import {
  Plus, PanelLeftClose, PanelLeft, Sun, Moon, Monitor,
  Settings, Search, X, GitBranch,
} from 'lucide-react';
import { useState, useMemo, useRef, useEffect, useCallback } from 'react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { ScrollArea } from '../ui/scroll-area';
import { Tooltip, TooltipContent, TooltipTrigger, TooltipProvider } from '../ui/tooltip';
import { agentStateDot } from './state-indicators';
import type { AppState } from '../../hooks/use-app-state';
import type { ThreadSummary, TeamTopology } from '../../data/types';

interface SidebarProps {
  state: AppState;
}

/** Human-readable topology label */
function topologyLabel(topology?: TeamTopology): string {
  switch (topology) {
    case 'star': return 'Star';
    case 'pipeline': return 'Pipeline';
    case 'pipeline_loop': return 'Loop';
    default: return '';
  }
}

/** Relative time label */
function timeAgo(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'now';
  if (mins < 60) return `${mins}m`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h`;
  const days = Math.floor(hrs / 24);
  return `${days}d`;
}

const MIN_WIDTH = 180;
const MAX_WIDTH = 420;

export function Sidebar({ state }: SidebarProps) {
  const {
    threads,
    activeTabId,
    openTransient,
    openPinned,
    clearActiveTab,
    sidebarCollapsed,
    toggleSidebar,
    themeMode,
    setThemeMode,
    sidebarWidth,
    setSidebarWidth,
  } = state;

  const [searchOpen, setSearchOpen] = useState(false);
  const [taskFilter, setTaskFilter] = useState('');
  const searchRef = useRef<HTMLInputElement>(null);
  const isResizing = useRef(false);

  useEffect(() => {
    if (searchOpen) setTimeout(() => searchRef.current?.focus(), 50);
    else setTaskFilter('');
  }, [searchOpen]);

  const filteredThreads = useMemo(() => {
    if (!taskFilter) return threads;
    const q = taskFilter.toLowerCase();
    return threads.filter(t => {
      const searchable = [
        t.nickname,
        t.title,
        t.feature_tag,
        t.source_branch,
        t.source_repo,
      ].filter(Boolean).join(' ').toLowerCase();
      return searchable.includes(q);
    });
  }, [threads, taskFilter]);

  // Drag-to-resize handler
  const handleMouseDown = useCallback(
    (e: React.MouseEvent) => {
      e.preventDefault();
      isResizing.current = true;
      const startX = e.clientX;
      const startWidth = sidebarWidth;

      const onMouseMove = (ev: MouseEvent) => {
        if (!isResizing.current) return;
        const newWidth = Math.max(MIN_WIDTH, Math.min(MAX_WIDTH, startWidth + (ev.clientX - startX)));
        setSidebarWidth(newWidth);
      };

      const onMouseUp = () => {
        isResizing.current = false;
        document.removeEventListener('mousemove', onMouseMove);
        document.removeEventListener('mouseup', onMouseUp);
        document.body.style.cursor = '';
        document.body.style.userSelect = '';
      };

      document.body.style.cursor = 'col-resize';
      document.body.style.userSelect = 'none';
      document.addEventListener('mousemove', onMouseMove);
      document.addEventListener('mouseup', onMouseUp);
    },
    [sidebarWidth, setSidebarWidth]
  );

  if (sidebarCollapsed) {
    return (
      <div className="flex flex-col items-center py-2 px-1 border-r border-border bg-oxide-sidebar-bg h-full w-12 shrink-0">
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button variant="ghost" size="icon" className="h-8 w-8" onClick={toggleSidebar}>
                <PanelLeft className="h-4 w-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent side="right">Expand sidebar (Ctrl+.)</TooltipContent>
          </Tooltip>
        </TooltipProvider>
      </div>
    );
  }
 
  return (
    <div className="relative flex flex-col border-r border-border bg-oxide-sidebar-bg h-full shrink-0" style={{ width: `${sidebarWidth / 16}rem` }}>
      {/* Header */}
      <div className="flex items-center justify-between px-3 py-2.5 border-b border-border">
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={toggleSidebar}>
            <PanelLeftClose className="h-4 w-4 text-oxide-icon" />
          </Button>
          <span className="text-[0.8125rem] font-bold tracking-tight text-foreground uppercase">VaultSpec</span>
        </div>
        <div className="flex items-center gap-0.5">
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-7 w-7 text-oxide-icon"
                  onClick={() => setThemeMode(themeMode === 'dark' ? 'light' : themeMode === 'light' ? 'system' : 'dark')}
                >
                  {themeMode === 'dark' ? <Moon className="h-3.5 w-3.5" /> : themeMode === 'light' ? <Sun className="h-3.5 w-3.5" /> : <Monitor className="h-3.5 w-3.5" />}
                </Button>
              </TooltipTrigger>
              <TooltipContent side="bottom">Theme: {themeMode}</TooltipContent>
            </Tooltip>
          </TooltipProvider>
          <Button variant="ghost" size="icon" className="h-7 w-7 text-oxide-icon">
            <Settings className="h-3.5 w-3.5" />
          </Button>
        </div>
      </div>
 
      {/* New Task Button — Unified Style */}
      <div className="px-3 pt-3 pb-2">
        <Button
          variant="outline"
          className="w-full justify-start gap-2 h-8 text-[0.75rem] font-mono uppercase tracking-wider rounded-control text-foreground/70 hover:text-foreground"
          onClick={() => clearActiveTab()}
        >
          <Plus className="h-3.5 w-3.5" />
          New Task
        </Button>
      </div>

      {/* Section header */}
      <div className="px-3 pb-1.5">
        <div className="flex items-center justify-between h-7">
          <div className="flex-1 min-w-0 mr-1">
            {searchOpen ? (
              <div className="relative flex items-center">
                <Search className="absolute left-2 h-3 w-3 text-muted-foreground pointer-events-none z-10" />
                <Input
                  ref={searchRef}
                  value={taskFilter}
                  onChange={(e) => setTaskFilter(e.target.value)}
                  onKeyDown={(e) => e.key === 'Escape' && setSearchOpen(false)}
                  placeholder="Filter tasks..."
                  className="h-6 pl-6 pr-2 text-[0.6875rem]"
                />
              </div>
            ) : (
              <span className="text-[0.625rem] font-bold uppercase tracking-widest text-text-dimmed px-1 select-none">
                Tasks
              </span>
            )}
          </div>

          <div className="flex items-center gap-0.5 shrink-0">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    className={`h-6 w-6 transition-colors ${searchOpen ? 'text-primary bg-primary/10' : 'text-text-dimmed hover:text-foreground'}`}
                    onClick={() => setSearchOpen(v => !v)}
                  >
                    {searchOpen ? <X className="h-3 w-3" /> : <Search className="h-3 w-3" />}
                  </Button>
                </TooltipTrigger>
                <TooltipContent side="bottom">{searchOpen ? 'Close search' : 'Search tasks'}</TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
        </div>
      </div>

      <ScrollArea className="flex-1 min-h-0">
        <div className="px-2 py-1 space-y-0.5">
          {filteredThreads.length === 0 && taskFilter && (
            <div className="px-3 py-4 text-center text-[0.6875rem] text-text-subtle italic">
              No tasks match &ldquo;{taskFilter}&rdquo;
            </div>
          )}
          {filteredThreads.length === 0 && !taskFilter && (
            <div className="px-3 py-4 text-center text-[0.6875rem] text-text-subtle italic">
              No tasks yet. Click &ldquo;New Task&rdquo; to start.
            </div>
          )}
          {filteredThreads.map((thread) => (
            <TaskItem
              key={thread.thread_id}
              thread={thread}
              isActive={activeTabId === thread.thread_id}
              onSelect={() => openTransient(thread.thread_id)}
              onDoubleClick={() => openPinned(thread.thread_id)}
            />
          ))}
        </div>
      </ScrollArea>

      {/* Resize handle */}
      <div
        onMouseDown={handleMouseDown}
        className="absolute top-0 right-0 w-1 h-full cursor-col-resize hover:bg-primary/30 active:bg-primary/50 transition-colors z-30"
      />
    </div>
  );
}

/** Single task row in the flat sidebar list */
function TaskItem({
  thread,
  isActive,
  onSelect,
  onDoubleClick,
}: {
  thread: ThreadSummary;
  isActive: boolean;
  onSelect: () => void;
  onDoubleClick: () => void;
}) {
  const clickTimeout = useRef<ReturnType<typeof setTimeout> | null>(null);
  const clickCount = useRef(0);

  const handleClick = () => {
    clickCount.current += 1;

    if (clickCount.current === 1) {
      // Single-click: open transient immediately
      onSelect();
      clickTimeout.current = setTimeout(() => {
        clickCount.current = 0;
      }, 300);
    } else if (clickCount.current === 2) {
      // Double-click: pin
      if (clickTimeout.current) clearTimeout(clickTimeout.current);
      clickCount.current = 0;
      onDoubleClick();
    }
  };

  const dot = agentStateDot(thread.agent_state);
  const displayName = thread.nickname || thread.title;
  const topoLabel = topologyLabel(thread.topology);

  return (
    <button
      onClick={handleClick}
      className={`w-full text-left rounded-ui px-2.5 py-2 transition-colors group ${
        isActive
          ? 'bg-accent text-accent-foreground shadow-sm border border-border/10'
          : 'hover:bg-accent/40 text-foreground/70'
      }`}
    >
      {/* Row 1: status dot + nickname + time */}
      <div className="flex items-start gap-2">
        {dot ? (
          <span className="shrink-0 w-4 flex items-center justify-center mt-0.5">{dot}</span>
        ) : (
          <span className="shrink-0 w-4 mt-0.5" />
        )}
        <span className={`flex-1 text-[0.75rem] break-words min-w-0 ${isActive ? 'font-bold' : ''}`}>
          {displayName}
        </span>
        <span className="text-[0.625rem] text-oxide-metadata shrink-0 tabular-nums mt-0.5">
          {timeAgo(thread.updated_at)}
        </span>
      </div>
 
      {/* Row 2: metadata — team kind label + feature tag + branch */}
      {(thread.feature_tag || thread.source_branch || thread.topology) && (
        <div className="flex items-center gap-1.5 mt-1 ml-6 flex-wrap">
          {topoLabel && (
            <span className="text-[0.625rem] text-oxide-metadata uppercase tracking-widest font-bold">
              {topoLabel}
            </span>
          )}
          {thread.feature_tag && (
            <span className="text-[0.625rem] text-oxide-metadata opacity-80 font-mono">
              #{thread.feature_tag}
            </span>
          )}
          {thread.source_branch && (
            <span className="flex items-center gap-0.5 text-[0.625rem] text-oxide-metadata font-mono">
              <GitBranch className="w-2.5 h-2.5 shrink-0" />
              {thread.source_branch}
            </span>
          )}
        </div>
      )}
    </button>
  );
}