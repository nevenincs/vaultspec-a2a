import type { AppState } from '../../hooks/use-app-state';

export function StatusBar({ state }: { state: AppState }) {
  const { connectionState, threads, lastHeartbeat } = state;

  const heartbeatAgo = ((Date.now() - lastHeartbeat) / 1000).toFixed(1);
  const activeCount = threads.filter(
    (t) => t.agent_state === 'working' || t.agent_state === 'submitted'
  ).length;

  const connDot =
    connectionState === 'connected'
      ? 'bg-status-success'
      : connectionState === 'reconnecting'
      ? 'bg-status-warning'
      : 'bg-status-error';

  const connLabel =
    connectionState === 'connected'
      ? 'Connected'
      : connectionState === 'reconnecting'
      ? 'Reconnecting...'
      : 'Disconnected';

  const barBg =
    connectionState === 'reconnecting'
      ? 'bg-status-warning/5'
      : connectionState === 'disconnected'
      ? 'bg-status-error/5'
      : '';

  return (
    <div
      className={`flex items-center justify-between px-4 h-6 border-t border-border text-[0.625rem] text-oxide-metadata shrink-0 bg-oxide-sidebar-bg font-mono uppercase tracking-wider select-none ${barBg}`}
    >
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2">
          <span className={`w-1.5 h-1.5 rounded-full ${connDot}`} />
          <span className="font-bold">{connLabel}</span>
        </div>
        <div className="flex items-center gap-1 opacity-60">
          <span className="text-[0.5625rem]">Latency</span>
          <span className="font-bold">42ms</span>
        </div>
      </div>
      <div className="flex items-center gap-4">
        <div>
          {threads.length} THREAD{threads.length !== 1 ? 'S' : ''} &middot; {activeCount} ACTIVE
        </div>
        <div className="flex items-center gap-1">
          <span className="text-[0.625rem] opacity-60">HEARTBEAT</span>
          <span className="font-bold">{heartbeatAgo}S</span>
        </div>
      </div>
    </div>
  );
}
