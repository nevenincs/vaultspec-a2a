import { X } from 'lucide-react';
import { useRef } from 'react';
import type { AppState } from '../../hooks/use-app-state';
import { agentStateDot } from './state-indicators';

interface TabBarProps {
  state: AppState;
}

export function TabBar({ state }: TabBarProps) {
  const { tabs, activeTabId, threads, activateTab, pinTab, closeTab } = state;
 
  if (tabs.length === 0) return null;
 
  return (
    <div className="flex items-end border-b border-border bg-oxide-sidebar-bg shrink-0 overflow-x-auto h-9">
      {tabs.map((tab) => {
        const thread = threads.find(t => t.thread_id === tab.threadId);
        const isActive = activeTabId === tab.threadId;
        const label = thread?.nickname || thread?.title || tab.threadId;
        const dot = thread ? agentStateDot(thread.agent_state) : null;
 
        return (
          <TabItem
            key={tab.threadId}
            label={label}
            isActive={isActive}
            isPinned={tab.isPinned}
            dot={dot}
            onActivate={() => activateTab(tab.threadId)}
            onPin={() => pinTab(tab.threadId)}
            onClose={() => closeTab(tab.threadId)}
          />
        );
      })}
    </div>
  );
}
 
function TabItem({
  label,
  isActive,
  isPinned,
  dot,
  onActivate,
  onPin,
  onClose,
}: {
  label: string;
  isActive: boolean;
  isPinned: boolean;
  dot: React.ReactNode;
  onActivate: () => void;
  onPin: () => void;
  onClose: () => void;
}) {
  const clickTimeout = useRef<ReturnType<typeof setTimeout> | null>(null);
  const clickCount = useRef(0);
 
  const handleMouseDown = (e: React.MouseEvent) => {
    // Middle-click closes
    if (e.button === 1) {
      e.preventDefault();
      onClose();
    }
  };
 
  const handleClick = (e: React.MouseEvent) => {
    if (e.button !== 0) return;
    clickCount.current += 1;
 
    if (clickCount.current === 1) {
      // Activate immediately on first click
      onActivate();
      clickTimeout.current = setTimeout(() => {
        clickCount.current = 0;
      }, 300);
    } else if (clickCount.current === 2) {
      // Double-click: pin
      if (clickTimeout.current) clearTimeout(clickTimeout.current);
      clickCount.current = 0;
      onPin();
    }
  };
 
  const handleCloseClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onClose();
  };
 
  return (
    <div
      onMouseDown={handleMouseDown}
      onClick={handleClick}
      className={`group relative flex items-center gap-1.5 h-full px-4 cursor-pointer select-none shrink-0 max-w-[14rem] border-r border-border/40 transition-all font-mono tracking-tight ${
        isActive
          ? 'bg-oxide-terminal-bg text-foreground shadow-[inset_0_2px_0_var(--primary)]'
          : 'bg-oxide-sidebar-bg text-oxide-metadata hover:text-foreground hover:bg-oxide-terminal-bg/50'
      }`}
    >
      {/* Status dot */}
      {dot && (
        <span className="shrink-0 flex items-center [&>svg]:w-3 [&>svg]:h-3 [&>span]:w-2 [&>span]:h-2">
          {dot}
        </span>
      )}
 
      {/* Label — italic when transient */}
      <span
        className={`text-[0.6875rem] truncate font-bold uppercase ${
          isPinned ? '' : 'italic opacity-60'
        }`}
      >
        {label}
      </span>
 
      {/* Close button */}
      <button
        onClick={handleCloseClick}
        className="shrink-0 ml-1.5 p-0.5 rounded-control opacity-0 group-hover:opacity-60 hover:!opacity-100 hover:bg-muted transition-all"
      >
        <X className="w-3 h-3" />
      </button>
    </div>
  );
}
