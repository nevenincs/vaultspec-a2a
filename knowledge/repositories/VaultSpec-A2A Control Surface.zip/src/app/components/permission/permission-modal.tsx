import {
  AlertDialog,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '../ui/alert-dialog';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { toolKindIcon } from '../layout/state-indicators';
import type { PermissionRequest } from '../../data/types';

interface PermissionModalProps {
  request: PermissionRequest;
  queueLength: number;
  onRespond: (requestId: string, optionId: string) => void;
}

export function PermissionModal({ request, queueLength, onRespond }: PermissionModalProps) {
  return (
    <AlertDialog open={true}>
      <AlertDialogContent className="max-w-md">
        <AlertDialogHeader>
          <AlertDialogTitle className="text-[0.9375rem]">Permission Required</AlertDialogTitle>
          <AlertDialogDescription className="text-[0.8125rem]">
            {request.agent_name} wants to use {request.tool_name}
          </AlertDialogDescription>
        </AlertDialogHeader>

        <div className="space-y-3 mt-1">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <span className="text-[0.75rem] text-muted-foreground w-14">Agent:</span>
              <span className="text-[0.8125rem] text-foreground">{request.agent_name}</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-[0.75rem] text-muted-foreground w-14">Tool:</span>
              <div className="flex items-center gap-1.5">
                {toolKindIcon(request.tool_kind, 'w-3.5 h-3.5 text-muted-foreground')}
                <span className="text-[0.8125rem] text-foreground font-mono">
                  {request.tool_name}
                </span>
              </div>
            </div>
          </div>

          <div className="bg-muted/50 rounded-lg px-3 py-2.5 border border-border">
            <p className="text-[0.8125rem] text-foreground">&ldquo;{request.message}&rdquo;</p>
          </div>
        </div>

        <AlertDialogFooter className="flex-row gap-2 mt-2">
          {request.options.map((option) => {
            const variant =
              option.kind === 'allow'
                ? 'default'
                : option.kind === 'deny'
                ? 'outline'
                : option.kind === 'allow_always'
                ? 'secondary'
                : 'ghost';
            const extraClass =
              option.kind === 'deny'
                ? 'text-status-error border-status-error/30 hover:bg-status-error/10 hover:text-status-error'
                : '';
            return (
              <Button
                key={option.id}
                variant={variant as any}
                size="sm"
                className={`text-[0.8125rem] ${extraClass}`}
                onClick={() => onRespond(request.id, option.id)}
              >
                {option.label}
              </Button>
            );
          })}
        </AlertDialogFooter>

        {queueLength > 1 && (
          <div className="flex justify-center mt-2">
            <Badge variant="secondary" className="text-[0.6875rem]">
              1 of {queueLength} pending
            </Badge>
          </div>
        )}
      </AlertDialogContent>
    </AlertDialog>
  );
}