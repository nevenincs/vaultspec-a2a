import type {
  ThreadSummary,
  AgentSummary,
  StreamEvent,
  PlanEntry,
  PermissionRequest,
  TeamPreset,
} from './types';

// --- Team Presets ---
export const teamPresets: TeamPreset[] = [
  {
    id: 'coding-star',
    name: 'Coding Team (Star)',
    topology: 'star',
    agents: ['Planner', 'Coder', 'Reviewer'],
    description: 'Star topology — Planner orchestrates Coder and Reviewer',
    status: 'active',
  },
  {
    id: 'review-pipeline',
    name: 'Review Pipeline',
    topology: 'pipeline',
    agents: ['Coder', 'Reviewer', 'Deployer'],
    description: 'Sequential pipeline — code flows through review to deploy',
    status: 'completed',
  },
  {
    id: 'research-loop',
    name: 'Research Loop',
    topology: 'pipeline_loop',
    agents: ['Researcher', 'Analyst', 'Writer'],
    description: 'Iterative pipeline — cycles until quality threshold met',
    status: 'on_hold',
  },
];

// --- Team Agents ---
export const teamAgents: AgentSummary[] = [
  { node_name: 'Planner', state: 'working', agent_id: 'planner-1' },
  { node_name: 'Coder', state: 'idle', agent_id: 'coder-1' },
  { node_name: 'Reviewer', state: 'idle', agent_id: 'reviewer-1' },
];

// --- Thread List ---
export const threads: ThreadSummary[] = [
  {
    thread_id: 'thread-001',
    title: 'Debug auth session bug',
    agent_state: 'working',
    updated_at: new Date(Date.now() - 3 * 60 * 1000).toISOString(),
    team_preset: 'coding-star',
    nickname: 'auth-fix-star-a3f2',
    feature_tag: 'auth-flow',
    source_repo: 'wgergely/vaultspec-a2a',
    source_branch: 'fix/auth-session',
    callee: 'claude-cli',
    topology: 'star',
  },
  {
    thread_id: 'thread-002',
    title: 'Refactor database models',
    agent_state: 'idle',
    updated_at: new Date(Date.now() - 12 * 60 * 1000).toISOString(),
    team_preset: 'coding-star',
    nickname: 'db-refactor-star-b7c1',
    feature_tag: 'sqlmodel-migration',
    source_repo: 'wgergely/vaultspec-a2a',
    source_branch: 'feat/sqlmodel',
    callee: 'api',
    topology: 'star',
  },
  {
    thread_id: 'thread-003',
    title: 'Add API rate limiting',
    agent_state: 'completed',
    updated_at: new Date(Date.now() - 45 * 60 * 1000).toISOString(),
    team_preset: 'review-pipeline',
    nickname: 'rate-limit-pipe-c4d9',
    feature_tag: 'rate-limiting',
    source_repo: 'wgergely/vaultspec-a2a',
    source_branch: 'feat/rate-limit',
    callee: 'gemini-cli',
    topology: 'pipeline',
  },
  {
    thread_id: 'thread-004',
    title: 'Update CI/CD pipeline',
    agent_state: 'failed',
    updated_at: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
    nickname: 'cicd-update-star-e8f0',
    feature_tag: 'github-actions',
    source_repo: 'wgergely/vaultspec-a2a',
    source_branch: 'chore/cicd',
    callee: 'mcp-bridge',
    topology: 'star',
  },
];

// --- Plan Entries (for thread-001) ---
export const planEntries: PlanEntry[] = [
  { id: 'pe-1', title: 'Analyze auth module', status: 'completed', priority: 'high' },
  { id: 'pe-2', title: 'Read session config', status: 'completed', priority: 'medium' },
  { id: 'pe-3', title: 'Fix token validation', status: 'in_progress', priority: 'high' },
  { id: 'pe-4', title: 'Update unit tests', status: 'pending', priority: 'low' },
  { id: 'pe-5', title: 'Run test suite', status: 'pending', priority: 'medium' },
];

// --- Stream Events (thread-001, chronological) ---
export const thread001Events: StreamEvent[] = [
  {
    id: 'ev-001',
    type: 'user_message',
    timestamp: new Date(Date.now() - 8 * 60 * 1000).toISOString(),
    thread_id: 'thread-001',
    content: 'The authentication sessions are expiring immediately after login. Users report being redirected to the login page right after signing in. Can you debug this?',
  },
  {
    id: 'ev-002',
    type: 'agent_status',
    timestamp: new Date(Date.now() - 7.9 * 60 * 1000).toISOString(),
    thread_id: 'thread-001',
    agent_id: 'planner-1',
    agent_name: 'Planner',
    old_state: 'idle',
    new_state: 'working',
  },
  {
    id: 'ev-003',
    type: 'thought',
    timestamp: new Date(Date.now() - 7.8 * 60 * 1000).toISOString(),
    thread_id: 'thread-001',
    agent_id: 'planner-1',
    agent_name: 'Planner',
    content: 'Need to check the session handling in middleware to understand the auth flow. The issue is likely in session cookie configuration or token expiry settings. Let me create a plan and delegate to the Coder.',
  },
  {
    id: 'ev-004',
    type: 'plan_update',
    timestamp: new Date(Date.now() - 7.5 * 60 * 1000).toISOString(),
    thread_id: 'thread-001',
    agent_id: 'planner-1',
    agent_name: 'Planner',
    entries: planEntries,
  },
  {
    id: 'ev-005',
    type: 'agent_message',
    timestamp: new Date(Date.now() - 7 * 60 * 1000).toISOString(),
    thread_id: 'thread-001',
    agent_id: 'planner-1',
    agent_name: 'Planner',
    content: "I've created an execution plan to debug the auth session issue. I'll start by analyzing the auth module and session configuration. Let me read the relevant files first.",
  },
  {
    id: 'ev-006',
    type: 'agent_status',
    timestamp: new Date(Date.now() - 6.9 * 60 * 1000).toISOString(),
    thread_id: 'thread-001',
    agent_id: 'coder-1',
    agent_name: 'Coder',
    old_state: 'idle',
    new_state: 'working',
  },
  {
    id: 'ev-007',
    type: 'tool_call',
    timestamp: new Date(Date.now() - 6.5 * 60 * 1000).toISOString(),
    thread_id: 'thread-001',
    agent_id: 'coder-1',
    agent_name: 'Coder',
    tool_call_id: 'tc-001',
    tool_name: 'read_file',
    tool_kind: 'read',
    status: 'completed',
    location: { file: 'src/auth/session.py', line: 1 },
    output: `import jwt
from datetime import datetime, timedelta
from fastapi import Request, Response

SESSION_EXPIRY = timedelta(seconds=0)  # BUG: expiry set to 0 seconds

def create_session(user_id: str, response: Response):
    token = jwt.encode(
        {"user_id": user_id, "exp": datetime.utcnow() + SESSION_EXPIRY},
        SECRET_KEY,
        algorithm="HS256"
    )
    response.set_cookie("session", token, httponly=True)
    return token

def validate_session(request: Request):
    token = request.cookies.get("session")
    if not token:
        raise AuthError("No session cookie")
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
        return payload["user_id"]
    except jwt.ExpiredSignatureError:
        raise AuthError("Session expired")`,
  },
  {
    id: 'ev-008',
    type: 'thought',
    timestamp: new Date(Date.now() - 6 * 60 * 1000).toISOString(),
    thread_id: 'thread-001',
    agent_id: 'coder-1',
    agent_name: 'Coder',
    content: 'Found it! `SESSION_EXPIRY = timedelta(seconds=0)` — the session expires immediately upon creation. This was likely introduced during testing and never reverted. The fix is to set a proper expiry duration like 24 hours.',
  },
  {
    id: 'ev-009',
    type: 'tool_call',
    timestamp: new Date(Date.now() - 5.5 * 60 * 1000).toISOString(),
    thread_id: 'thread-001',
    agent_id: 'coder-1',
    agent_name: 'Coder',
    tool_call_id: 'tc-002',
    tool_name: 'read_file',
    tool_kind: 'read',
    status: 'completed',
    location: { file: 'config/settings.toml', line: 12 },
    output: `[auth]
secret_key = "dev-secret-key-change-in-production"
session_duration_hours = 24
cookie_secure = false
cookie_samesite = "lax"`,
  },
  {
    id: 'ev-010',
    type: 'agent_message',
    timestamp: new Date(Date.now() - 5 * 60 * 1000).toISOString(),
    thread_id: 'thread-001',
    agent_id: 'coder-1',
    agent_name: 'Coder',
    content: "Found the bug. In `src/auth/session.py`, `SESSION_EXPIRY` is set to `timedelta(seconds=0)`, meaning sessions expire immediately. The config file at `config/settings.toml` has `session_duration_hours = 24`, but this value is **never read** by the session module. I'll fix this now.",
  },
  {
    id: 'ev-011',
    type: 'tool_call',
    timestamp: new Date(Date.now() - 4.5 * 60 * 1000).toISOString(),
    thread_id: 'thread-001',
    agent_id: 'coder-1',
    agent_name: 'Coder',
    tool_call_id: 'tc-003',
    tool_name: 'edit_file',
    tool_kind: 'edit',
    status: 'completed',
    location: { file: 'src/auth/session.py', line: 5 },
    diff: {
      old_content: 'SESSION_EXPIRY = timedelta(seconds=0)  # BUG: expiry set to 0 seconds',
      new_content: `import tomllib
from pathlib import Path

_config = tomllib.loads(Path("config/settings.toml").read_text())
SESSION_EXPIRY = timedelta(hours=_config["auth"]["session_duration_hours"])`,
    },
  },
  {
    id: 'ev-012',
    type: 'artifact',
    timestamp: new Date(Date.now() - 4 * 60 * 1000).toISOString(),
    thread_id: 'thread-001',
    agent_id: 'coder-1',
    agent_name: 'Coder',
    artifact_id: 'art-001',
    filename: 'src/auth/session.py',
    complete: true,
    content: `import jwt
import tomllib
from datetime import datetime, timedelta
from pathlib import Path
from fastapi import Request, Response

_config = tomllib.loads(Path("config/settings.toml").read_text())
SESSION_EXPIRY = timedelta(hours=_config["auth"]["session_duration_hours"])

def create_session(user_id: str, response: Response):
    token = jwt.encode(
        {"user_id": user_id, "exp": datetime.utcnow() + SESSION_EXPIRY},
        SECRET_KEY,
        algorithm="HS256"
    )
    response.set_cookie("session", token, httponly=True)
    return token

def validate_session(request: Request):
    token = request.cookies.get("session")
    if not token:
        raise AuthError("No session cookie")
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
        return payload["user_id"]
    except jwt.ExpiredSignatureError:
        raise AuthError("Session expired")`,
    old_content: `import jwt
from datetime import datetime, timedelta
from fastapi import Request, Response

SESSION_EXPIRY = timedelta(seconds=0)  # BUG: expiry set to 0 seconds

def create_session(user_id: str, response: Response):
    token = jwt.encode(
        {"user_id": user_id, "exp": datetime.utcnow() + SESSION_EXPIRY},
        SECRET_KEY,
        algorithm="HS256"
    )
    response.set_cookie("session", token, httponly=True)
    return token

def validate_session(request: Request):
    token = request.cookies.get("session")
    if not token:
        raise AuthError("No session cookie")
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
        return payload["user_id"]
    except jwt.ExpiredSignatureError:
        raise AuthError("Session expired")`,
  },
  {
    id: 'ev-013',
    type: 'tool_call',
    timestamp: new Date(Date.now() - 3.5 * 60 * 1000).toISOString(),
    thread_id: 'thread-001',
    agent_id: 'coder-1',
    agent_name: 'Coder',
    tool_call_id: 'tc-004',
    tool_name: 'execute_shell',
    tool_kind: 'execute',
    status: 'running',
    input: 'cd /workspace && python -m pytest tests/auth/ -v',
  },
  {
    id: 'ev-014',
    type: 'agent_message',
    timestamp: new Date(Date.now() - 3 * 60 * 1000).toISOString(),
    thread_id: 'thread-001',
    agent_id: 'coder-1',
    agent_name: 'Coder',
    content: `I've fixed the session expiry bug and am running the auth test suite. Here's a summary:

## Root Cause
\`SESSION_EXPIRY = timedelta(seconds=0)\` — sessions expired **immediately** upon creation.

## Fix Applied
The module now reads \`session_duration_hours\` from \`config/settings.toml\`:

\`\`\`python
import tomllib
from pathlib import Path

_config = tomllib.loads(Path("config/settings.toml").read_text())
SESSION_EXPIRY = timedelta(hours=_config["auth"]["session_duration_hours"])
\`\`\`

## What changed
- **Before:** hardcoded \`timedelta(seconds=0)\`
- **After:** reads from config → \`timedelta(hours=24)\`
- Config key: \`[auth] session_duration_hours = 24\`

> The fix also makes session duration configurable per environment — no more hardcoded values.

Running \`pytest tests/auth/ -v\` now…`,
    streaming: true,
  },
];

// --- Stream Events (thread-002) ---
export const thread002Events: StreamEvent[] = [
  {
    id: 'ev-201',
    type: 'user_message',
    timestamp: new Date(Date.now() - 15 * 60 * 1000).toISOString(),
    thread_id: 'thread-002',
    content: 'Can you refactor the User and Project models to use SQLModel instead of raw SQLAlchemy? Keep all existing relationships intact.',
  },
  {
    id: 'ev-202',
    type: 'agent_message',
    timestamp: new Date(Date.now() - 14 * 60 * 1000).toISOString(),
    thread_id: 'thread-002',
    agent_id: 'planner-1',
    agent_name: 'Planner',
    content: "I'll analyze the existing model structure and create a migration plan. SQLModel combines Pydantic and SQLAlchemy, so we'll get type safety and validation automatically. Let me map out the dependencies first.",
  },
  {
    id: 'ev-203',
    type: 'tool_call',
    timestamp: new Date(Date.now() - 13 * 60 * 1000).toISOString(),
    thread_id: 'thread-002',
    agent_id: 'coder-1',
    agent_name: 'Coder',
    tool_call_id: 'tc-201',
    tool_name: 'search_files',
    tool_kind: 'search',
    status: 'completed',
    input: 'class.*Model.*Base',
    output: 'Found 4 model files:\n  src/models/user.py\n  src/models/project.py\n  src/models/team.py\n  src/models/audit_log.py',
  },
];

// --- Stream Events (thread-003) ---
export const thread003Events: StreamEvent[] = [
  {
    id: 'ev-301',
    type: 'user_message',
    timestamp: new Date(Date.now() - 50 * 60 * 1000).toISOString(),
    thread_id: 'thread-003',
    content: 'Please add rate limiting to all API endpoints. Use a sliding window approach with configurable limits per endpoint group.',
  },
  {
    id: 'ev-302',
    type: 'agent_message',
    timestamp: new Date(Date.now() - 48 * 60 * 1000).toISOString(),
    thread_id: 'thread-003',
    agent_id: 'planner-1',
    agent_name: 'Planner',
    content: "Rate limiting is now fully implemented using a sliding window algorithm with Redis as the backend store. All API endpoints are covered with configurable limits per endpoint group (auth: 10/min, api: 60/min, uploads: 5/min).",
  },
  {
    id: 'ev-303',
    type: 'agent_status',
    timestamp: new Date(Date.now() - 47 * 60 * 1000).toISOString(),
    thread_id: 'thread-003',
    agent_id: 'planner-1',
    agent_name: 'Planner',
    old_state: 'working',
    new_state: 'completed',
  },
];

// --- Stream Events (thread-004) ---
export const thread004Events: StreamEvent[] = [
  {
    id: 'ev-401',
    type: 'user_message',
    timestamp: new Date(Date.now() - 2.1 * 60 * 60 * 1000).toISOString(),
    thread_id: 'thread-004',
    content: 'Update the CI/CD pipeline to use GitHub Actions instead of CircleCI.',
  },
  {
    id: 'ev-402',
    type: 'agent_status',
    timestamp: new Date(Date.now() - 2.05 * 60 * 60 * 1000).toISOString(),
    thread_id: 'thread-004',
    agent_id: 'planner-1',
    agent_name: 'Planner',
    old_state: 'idle',
    new_state: 'working',
  },
  {
    id: 'ev-403',
    type: 'error',
    timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
    thread_id: 'thread-004',
    message: 'Connection to agent "Planner" lost. The agent process exited unexpectedly.',
    code: 'AGENT_TIMEOUT',
  },
  {
    id: 'ev-404',
    type: 'agent_status',
    timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
    thread_id: 'thread-004',
    agent_id: 'planner-1',
    agent_name: 'Planner',
    old_state: 'working',
    new_state: 'failed',
  },
];

// --- Event map by thread ---
export const eventsByThread: Record<string, StreamEvent[]> = {
  'thread-001': thread001Events,
  'thread-002': thread002Events,
  'thread-003': thread003Events,
  'thread-004': thread004Events,
};

// --- Permission Request (demo) ---
export const demoPermissionRequest: PermissionRequest = {
  id: 'perm-001',
  agent_id: 'coder-1',
  agent_name: 'Coder',
  tool_name: 'execute_shell',
  tool_kind: 'execute',
  message: 'Run npm install in the project root to install new dependencies required for the rate limiter.',
  options: [
    { id: 'opt-1', kind: 'allow', label: 'Allow' },
    { id: 'opt-2', kind: 'deny', label: 'Deny' },
    { id: 'opt-3', kind: 'allow_always', label: 'Always Allow' },
  ],
};