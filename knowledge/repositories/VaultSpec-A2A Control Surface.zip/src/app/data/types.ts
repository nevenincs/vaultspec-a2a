// VaultSpec Control Surface — TypeScript types (mirrors Pydantic schemas)

export type AgentLifecycleState =
  | 'submitted'
  | 'idle'
  | 'working'
  | 'input_required'
  | 'auth_required'
  | 'completed'
  | 'failed'
  | 'cancelled';

export type ToolKind = 'read' | 'edit' | 'search' | 'execute' | 'browser' | 'mcp' | 'other';
export type ToolCallStatus = 'pending' | 'running' | 'completed' | 'failed';
export type PlanEntryStatus = 'pending' | 'in_progress' | 'completed';
export type PlanEntryPriority = 'high' | 'medium' | 'low';
export type PermissionOptionKind = 'allow' | 'deny' | 'allow_always' | 'deny_always';
export type Provider = 'anthropic' | 'openai' | 'google';
export type TeamTopology = 'star' | 'pipeline' | 'pipeline_loop';

export interface AgentSummary {
  node_name: string;
  state: AgentLifecycleState;
  agent_id: string;
}

export interface ThreadSummary {
  thread_id: string;
  title: string;
  agent_state: AgentLifecycleState;
  updated_at: string;
  team_preset?: string;
  // ADR-014: Thread metadata fields
  nickname?: string;
  feature_tag?: string;
  source_repo?: string;
  source_branch?: string;
  callee?: string;
  topology?: TeamTopology;
}

export interface PlanEntry {
  id: string;
  title: string;
  status: PlanEntryStatus;
  priority: PlanEntryPriority;
}

export interface PermissionOption {
  id: string;
  kind: PermissionOptionKind;
  label: string;
}

export interface ToolCallLocation {
  file?: string;
  line?: number;
}

// Stream event types (for the chronological timeline)
export type StreamEventType =
  | 'user_message'
  | 'agent_message'
  | 'thought'
  | 'tool_call'
  | 'artifact'
  | 'plan_update'
  | 'agent_status'
  | 'error';

export interface BaseStreamEvent {
  id: string;
  type: StreamEventType;
  timestamp: string;
  thread_id: string;
}

export interface UserMessageEvent extends BaseStreamEvent {
  type: 'user_message';
  content: string;
}

export interface AgentMessageEvent extends BaseStreamEvent {
  type: 'agent_message';
  agent_id: string;
  agent_name: string;
  content: string;
  streaming?: boolean;
}

export interface ThoughtEvent extends BaseStreamEvent {
  type: 'thought';
  agent_id: string;
  agent_name: string;
  content: string;
  streaming?: boolean;
}

export interface ToolCallEvent extends BaseStreamEvent {
  type: 'tool_call';
  agent_id: string;
  agent_name: string;
  tool_call_id: string;
  tool_name: string;
  tool_kind: ToolKind;
  status: ToolCallStatus;
  location?: ToolCallLocation;
  input?: string;
  output?: string;
  diff?: { old_content: string; new_content: string };
  error?: string;
}

export interface ArtifactEvent extends BaseStreamEvent {
  type: 'artifact';
  agent_id: string;
  agent_name: string;
  artifact_id: string;
  filename: string;
  content: string;
  complete: boolean;
  old_content?: string;
}

export interface PlanUpdateEvent extends BaseStreamEvent {
  type: 'plan_update';
  agent_id: string;
  agent_name: string;
  entries: PlanEntry[];
}

export interface AgentStatusEvent extends BaseStreamEvent {
  type: 'agent_status';
  agent_id: string;
  agent_name: string;
  old_state: AgentLifecycleState;
  new_state: AgentLifecycleState;
}

export interface ErrorStreamEvent extends BaseStreamEvent {
  type: 'error';
  message: string;
  code?: string;
  agent_id?: string;
}

export type StreamEvent =
  | UserMessageEvent
  | AgentMessageEvent
  | ThoughtEvent
  | ToolCallEvent
  | ArtifactEvent
  | PlanUpdateEvent
  | AgentStatusEvent
  | ErrorStreamEvent;

export interface PermissionRequest {
  id: string;
  agent_id: string;
  agent_name: string;
  tool_name: string;
  tool_kind: ToolKind;
  message: string;
  options: PermissionOption[];
}

export type TeamStatus = 'active' | 'on_hold' | 'completed';

export interface TeamPreset {
  id: string;
  name: string;
  topology: TeamTopology;
  agents: string[];
  description: string;
  status?: TeamStatus;
  archived?: boolean;
}

export type ConnectionState = 'connected' | 'reconnecting' | 'disconnected';

export interface ContextDocument {
  id: string;
  title: string;
  content: string;
  type: 'file' | 'url' | 'note' | 'api';
  updated_at: string;
}

export interface InspectorTarget {
  type: 'document' | 'tool_call' | 'artifact' | 'plan' | 'context_list';
  document?: ContextDocument;
  documents?: ContextDocument[];
  event?: ToolCallEvent | ArtifactEvent | PlanUpdateEvent;
}

export interface Team {
  id: string;
  name: string;
  preset_id: string;
  threads: ThreadSummary[];
  agents: AgentSummary[];
}

export type ThemeMode = 'dark' | 'light' | 'system';

export interface EditorTab {
  threadId: string;
  isPinned: boolean;
}