import { useState, useCallback, useMemo, useEffect } from 'react';
import type {
  ThreadSummary,
  AgentSummary,
  StreamEvent,
  InspectorTarget,
  ConnectionState,
  ThemeMode,
  PermissionRequest,
  TeamPreset,
  ContextDocument,
  EditorTab,
} from '../data/types';
import {
  threads as initialThreads,
  teamAgents as initialAgents,
  eventsByThread,
  teamPresets,
} from '../data/mock-data';

// Rich set of mock context documents shared across the workspace
const initialContextDocuments: ContextDocument[] = [
  {
    id: 'doc-1',
    title: 'vaultspec-a2a-spec.md',
    content: `# VaultSpec A2A — Architecture Specification\n\n## Overview\nMulti-agent LLM orchestrator using LangGraph for agent graphs and FastAPI for the API layer.\n\n## Topology Types\n- **star**: Single orchestrator agent delegates to N workers\n- **pipeline**: Sequential chain of agents\n- **pipeline_loop**: Iterative pipeline that cycles until a quality threshold is met\n\n## Agent Lifecycle States\nsubmitted → idle → working → (input_required | completed | failed)\n\n## API Endpoints\n- GET /threads — list all threads\n- POST /threads — create thread\n- GET /threads/{id}/events — stream events (SSE)\n- GET /agents — list agents in active team`,
    type: 'file',
    updated_at: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: 'doc-2',
    title: 'api-reference.md',
    content: `# VaultSpec REST API\n\n## Authentication\nAll endpoints require: Authorization: Bearer <token>\n\n## Threads\nGET    /threads                  List all threads\nPOST   /threads                  Create thread  { title, team_preset }\nDELETE /threads/:id              Archive thread\n\n## Agents\nGET    /agents                   List agents\nGET    /agents/:id/state         Get agent lifecycle state\n\n## Events (SSE)\nGET    /threads/:id/events       Stream events\n  event: agent_message\n  event: tool_call\n  event: thought\n  event: plan_update\n  event: agent_status`,
    type: 'file',
    updated_at: new Date(Date.now() - 4 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: 'doc-3',
    title: 'langgraph-notes.md',
    content: `# LangGraph Integration Notes\n\nLangGraph documentation — stateful, multi-actor LLM applications.\n\n## Key Concepts\n- StateGraph for defining agent workflows\n- Checkpointing for conversation persistence\n- Human-in-the-loop via interrupt nodes`,
    type: 'file',
    updated_at: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: 'doc-4',
    title: 'session-auth.md',
    content: `# Session & Auth Implementation\n\n\`\`\`python\nimport jwt\nimport tomllib\nfrom datetime import datetime, timedelta\nfrom pathlib import Path\nfrom fastapi import Request, Response\n\n_config = tomllib.loads(Path("config/settings.toml").read_text())\nSESSION_EXPIRY = timedelta(hours=_config["auth"]["session_duration_hours"])\n\ndef create_session(user_id: str, response: Response):\n    token = jwt.encode(\n        {"user_id": user_id, "exp": datetime.utcnow() + SESSION_EXPIRY},\n        SECRET_KEY,\n        algorithm="HS256"\n    )\n    response.set_cookie("session", token, httponly=True)\n    return token\n\`\`\``,
    type: 'file',
    updated_at: new Date(Date.now() - 30 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: 'doc-5',
    title: 'sprint-7-notes.md',
    content: `# Sprint 7 Notes\n\n## Auth Bug (RESOLVED)\n- SESSION_EXPIRY was set to timedelta(seconds=0)\n- Fix: read from config/settings.toml\n- PR #142 merged\n\n## Next up\n- [ ] SQLModel migration for User/Project models\n- [ ] Rate limiting middleware (sliding window)\n- [ ] GitHub Actions CI/CD pipeline`,
    type: 'file',
    updated_at: new Date(Date.now() - 15 * 60 * 60 * 1000).toISOString(),
  },
];

export function useAppState() {
  // --- Theme ---
  const [themeMode, setThemeMode] = useState<ThemeMode>('dark');

  useEffect(() => {
    const root = document.documentElement;
    if (themeMode === 'dark') {
      root.classList.add('dark');
    } else if (themeMode === 'light') {
      root.classList.remove('dark');
    } else {
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      if (prefersDark) root.classList.add('dark');
      else root.classList.remove('dark');
    }
  }, [themeMode]);

  // --- Connection ---
  const [connectionState] = useState<ConnectionState>('connected');
  const [lastHeartbeat] = useState(Date.now() - 1200);

  // --- Threads ---
  const [threads, setThreads] = useState<ThreadSummary[]>(initialThreads);

  // --- Agents ---
  const [agents] = useState<AgentSummary[]>(initialAgents);

  // --- Stream Events ---
  const [streamEvents] = useState<Record<string, StreamEvent[]>>(eventsByThread);

  // ═══════════════════════════════════════════════════════════════════════════
  // Tabs — VS Code-style preview/transient tab system
  // ═══════════════════════════════════════════════════════════════════════════
  const [tabs, setTabs] = useState<EditorTab[]>([]);
  const [activeTabId, setActiveTabId] = useState<string | null>(null);

  // Derived active thread (from tabs, not raw threadId)
  const activeThread = useMemo(
    () => {
      if (!activeTabId) return null;
      const hasTab = tabs.some(t => t.threadId === activeTabId);
      if (!hasTab) return null;
      return threads.find(t => t.thread_id === activeTabId) || null;
    },
    [activeTabId, tabs, threads]
  );

  const activeEvents = useMemo(
    () => (activeTabId ? streamEvents[activeTabId] || [] : []),
    [activeTabId, streamEvents]
  );

  /** Single-click: open as transient (preview). Replaces any existing transient tab. */
  const openTransient = useCallback((threadId: string) => {
    setTabs(prev => {
      // Already open? Just activate it.
      if (prev.some(t => t.threadId === threadId)) return prev;
      // Remove existing transient tab, append new one
      const pinned = prev.filter(t => t.isPinned);
      return [...pinned, { threadId, isPinned: false }];
    });
    setActiveTabId(threadId);
  }, []);

  /** Double-click: open and immediately pin. */
  const openPinned = useCallback((threadId: string) => {
    setTabs(prev => {
      const existing = prev.find(t => t.threadId === threadId);
      if (existing) {
        // Already open — just pin it
        return prev.map(t => t.threadId === threadId ? { ...t, isPinned: true } : t);
      }
      // Remove existing transient, add as pinned
      const withoutTransient = prev.filter(t => t.isPinned);
      return [...withoutTransient, { threadId, isPinned: true }];
    });
    setActiveTabId(threadId);
  }, []);

  /** Pin the tab for a given threadId (e.g. double-click on tab label). */
  const pinTab = useCallback((threadId: string) => {
    setTabs(prev => prev.map(t =>
      t.threadId === threadId ? { ...t, isPinned: true } : t
    ));
  }, []);

  /** Close a tab. Activates adjacent tab if closing the active one. */
  const closeTab = useCallback((threadId: string) => {
    setTabs(prev => {
      const idx = prev.findIndex(t => t.threadId === threadId);
      const next = prev.filter(t => t.threadId !== threadId);
      if (threadId === activeTabId) {
        if (next.length === 0) {
          setActiveTabId(null);
        } else {
          const newIdx = Math.min(idx, next.length - 1);
          setActiveTabId(next[newIdx].threadId);
        }
      }
      return next;
    });
  }, [activeTabId]);

  /** Activate an already-open tab by threadId. */
  const activateTab = useCallback((threadId: string) => {
    setActiveTabId(threadId);
  }, []);

  /** Deselect all tabs — show the welcome/empty state. */
  const clearActiveTab = useCallback(() => {
    setActiveTabId(null);
  }, []);

  // --- Sidebar ---
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [sidebarWidth, setSidebarWidth] = useState(240);
  const toggleSidebar = useCallback(() => setSidebarCollapsed((v) => !v), []);

  // --- Context Documents ---
  const [contextDocuments] = useState<ContextDocument[]>(initialContextDocuments);

  // --- Inspector ---
  const [inspectorTarget, setInspectorTarget] = useState<InspectorTarget | null>(null);
  const closeInspector = useCallback(() => setInspectorTarget(null), []);
  const openInspector = useCallback((target: InspectorTarget) => setInspectorTarget(target), []);

  const openDocument = useCallback((doc: ContextDocument) => {
    setInspectorTarget({ type: 'document', document: doc });
  }, []);

  const toggleContextPanel = useCallback((docs: ContextDocument[]) => {
    setInspectorTarget((prev) => {
      if (prev?.type === 'context_list') return null; // toggle off
      return { type: 'context_list', documents: docs };
    });
  }, []);

  // --- Permission ---
  const [permissionQueue, setPermissionQueue] = useState<PermissionRequest[]>([]);
  const currentPermission = permissionQueue[0] || null;
  const respondToPermission = useCallback(
    (_requestId: string, _optionId: string) => {
      setPermissionQueue((q) => q.slice(1));
    },
    []
  );

  // --- Thread Creation ---
  const createThread = useCallback(
    (message: string, opts?: {
      preset?: TeamPreset;
      repo?: string;
      branch?: string;
      featureTag?: string;
    }) => {
      const preset = opts?.preset;
      const newId = `thread-${Date.now()}`;
      const shortHash = newId.slice(-4);
      const featureSlug = (opts?.featureTag || message)
        .slice(0, 30)
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/^-|-$/g, '');
      const topology = preset?.topology || 'star';
      const nickname = featureSlug
        ? `${featureSlug}-${topology}-${shortHash}`
        : `task-${topology}-${shortHash}`;

      const newThread: ThreadSummary = {
        thread_id: newId,
        title: message.slice(0, 40) + (message.length > 40 ? '...' : ''),
        agent_state: 'submitted',
        updated_at: new Date().toISOString(),
        team_preset: preset?.id,
        nickname,
        feature_tag: opts?.featureTag || featureSlug || undefined,
        source_repo: opts?.repo,
        source_branch: opts?.branch,
        topology,
        callee: 'api',
      };
      setThreads((prev) => [newThread, ...prev]);
      // New threads open as pinned (you committed to creating it)
      setTabs(prev => [...prev, { threadId: newId, isPinned: true }]);
      setActiveTabId(newId);
    },
    []
  );

  return {
    themeMode,
    setThemeMode,
    connectionState,
    lastHeartbeat,
    threads,
    activeThread,
    activeEvents,
    agents,
    // Tabs
    tabs,
    activeTabId,
    openTransient,
    openPinned,
    pinTab,
    closeTab,
    activateTab,
    clearActiveTab,
    // Sidebar
    sidebarCollapsed,
    sidebarWidth,
    setSidebarWidth,
    toggleSidebar,
    contextDocuments,
    inspectorTarget,
    openInspector,
    closeInspector,
    toggleContextPanel,
    permissionQueue,
    currentPermission,
    respondToPermission,
    setPermissionQueue,
    createThread,
    teamPresets,
    openDocument,
  };
}

export type AppState = ReturnType<typeof useAppState>;